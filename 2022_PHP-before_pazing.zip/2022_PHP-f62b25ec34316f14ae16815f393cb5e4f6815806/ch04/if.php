<?php
    if(0) 
    {
        print "안녕하세요";
    }  
    else 
    {
        print "안녕히 가세요.";
    }
?>