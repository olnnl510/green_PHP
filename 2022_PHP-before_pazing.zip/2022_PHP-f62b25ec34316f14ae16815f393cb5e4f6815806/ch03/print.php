<?php
    print ("<div>Hello PHP</div>");
    print "<div class='cls1'>Hello PHP</div>";    
?>




