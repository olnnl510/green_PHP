<?php
    $value = 999_999_999_999_999_997;

    print $value;

    print "<br>";
    $value2 = 9900000000000000001;
    print $value2;

    print "<br>";

    $value3 = "99999999900000000000000001";
    print $value3;
?>