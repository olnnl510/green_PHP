<?php
    $n1 = 9;
    $n2 = 5;

    $result = $n1 + $n2;
    print "$n1 + $n2 = $result <br>";

    $result = $n1 - $n2;
    print "$n1 - $n2 = $result <br>";

    $result = $n1 * $n2;
    print "$n1 * $n2 = $result <br>";

    $result = $n1 / $n2;
    print "$n1 / $n2 = $result <br>";

    $result = $n1 % $n2; //modulo
    print "$n1 % $n2 = $result <br>";
?>