<?php
   function sum() 
   {
       print "sum";
   }

   function sum2()
   {
       print "sum2";
   }
   print "bb";
   //print 10/0;
   print "aaa";
?>