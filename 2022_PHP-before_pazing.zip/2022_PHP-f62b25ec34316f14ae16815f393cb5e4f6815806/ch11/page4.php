<?php
    session_start();
    print $_SESSION['g'];
    $a = 10;

    echo $_SESSION['g'] , ', ' , $a; 
    