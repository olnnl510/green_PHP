<?php
    session_start();
    echo "Session ID : ", session_id();