<?php
    $g = "This is a Global variable";
?>
<a href="page2.php">Next page</a>
<?=$g?>
